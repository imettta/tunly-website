// 1. Handle "Start Exploring" button on the homepage
const mainButton = document.getElementById("heroButton");
if (mainButton) {
  mainButton.addEventListener("click", () => {
    window.location.href = "genres.html";
  });
}

const artists = [
  {
    name: "Billie Eilish",
    image: "assets/images/billie-eilish.jpg",
    description: "Grammy-winning pop innovator known for her dark, haunting style.",
    genre: "Pop",  
    profileLink: "artist-pages/billie-eilish.html"
  },
  {
    name: "Drake",
    image: "assets/images/drake.jpg",
    description: "Canadian rapper and singer with a global pop-rap dominance.",
    genre: "Rap", 
    profileLink: "artist-pages/drake.html"
  },
  {
    name: "Doja Cat",
    image: "assets/images/doja-cat.jpg",
    description: "Chart-topping genre-mixer blending rap, pop, and internet culture.",
    genre: "Rap",  
    profileLink: "artist-pages/doja-cat.html"
  },
  {
    name: "The Weeknd",
    image: "assets/images/the-weeknd.jpg",
    description: "Cinematic R&B artist behind 'Blinding Lights' and other hits.",
    genre: "R&B", 
    profileLink: "artist-pages/the-weeknd.html"
  },
  {
    name: "Kendrick Lamar",
    image: "assets/images/kendrick-lamar.jpg",
    description: "Pulitzer-winning lyricist reshaping modern hip-hop.",
    genre: "Rap", 
    profileLink: "artist-pages/kendrick-lamar.html"
  },
  {
    name: "Arctic Monkeys",
    image: "assets/images/arctic-monkeys.jpg",
    description: "Indie rock band with sharp lyrics and British swagger.",
    genre: "Rock", 
    profileLink: "artist-pages/arctic-monkeys.html"
  },
  {
    name: "Nirvana",
    image: "assets/images/nirvana.jpg",
    description: "Grunge pioneers who defined 90s rock.",
    genre: "Rock",  
    profileLink: "artist-pages/nirvana.html"
  },
  {
    name: "The Beatles",
    image: "assets/images/the-beatles.jpg",
    description: "Legendary band that transformed music in the 60s.",
    genre: "Rock", 
    profileLink: "artist-pages/the-beatles.html"
  },
  {
    name: "Queen",
    image: "assets/images/queen.jpg",
    description: "Theatrical rock legends led by Freddie Mercury.",
    genre: "Rock", 
    profileLink: "artist-pages/queen.html"
  },
  {
    name: "Eminem",
    image: "assets/images/eminem.jpg",
    description: "One of the most influential rappers of all time.",
    genre: "Rap", 
    profileLink: "artist-pages/eminem.html"
  },
  {
    name: "Olivia Rodrigo",
    image: "assets/images/olivia-rodrigo.jpg",
    description: "Teen sensation behind pop-rock breakup anthems.",
    genre: "Pop", 
    profileLink: "artist-pages/olivia-rodrigo.html"
  },
  {
    name: "Travis Scott",
    image: "assets/images/travis-scott.jpg",
    description: "Genre-pushing rapper with high-energy performances.",
    genre: "Rap",  
    profileLink: "artist-pages/travis-scott.html"
  },
  {
    name: "Tyler, The Creator",
    image: "assets/images/tyler-the-creator.jpg",
    description: "Visionary artist blending rap with jazz and funk.",
    genre: "Hip-Hop", 
    profileLink: "artist-pages/tyler-the-creator.html"
  },
  {
    name: "Phoebe Bridgers",
    image: "assets/images/phoebe-bridgers.jpg",
    description: "Indie folk star with raw, emotional songwriting.",
    genre: "Indie", 
    profileLink: "artist-pages/phoebe-bridgers.html"
  },
  {
    name: "Mac Miller",
    image: "assets/images/mac-miller.jpg",
    description: "Beloved rapper with introspective lyrics and jazz vibes.",
    genre: "Hip-Hop",  
    profileLink: "artist-pages/mac-miller.html"
  },
  {
    name: "Adele",
    image: "assets/images/adele.jpg",
    description: "British powerhouse known for her emotional ballads.",
    genre: "Pop",  
    profileLink: "artist-pages/adele.html"
  },
  {
    name: "Paramore",
    image: "assets/images/paramore.jpg",
    description: "Energetic pop-punk band with powerful vocals.",
    genre: "Rock",  
    profileLink: "artist-pages/paramore.html"
  },
  {
    name: "Green Day",
    image: "assets/images/green-day.jpg",
    description: "Punk rock band famous for catchy political anthems.",
    genre: "Rock",  
    profileLink: "artist-pages/green-day.html"
  },
  {
    name: "Snoop Dogg",
    image: "assets/images/snoop-dogg.jpg",
    description: "West Coast rap icon with laid-back charm.",
    genre: "Rap", 
    profileLink: "artist-pages/snoop-dogg.html"
  },
  {
    name: "A$AP Rocky",
    image: "assets/images/aap-rocky.jpg",
    description: "Fashion-forward rapper with a smooth flow.",
    genre: "Hip-Hop", 
    profileLink: "artist-pages/aap-rocky.html"
  },
  {
    name: "21 Savage",
    image: "assets/images/21-savage.jpg",
    description: "Atlanta rapper known for minimal beats and dark lyrics.",
    genre: "Rap",
    profileLink: "artist-pages/21-savage.html"
  },
  {
    name: "Fleetwood Mac",
    image: "assets/images/fleetwood-mac.jpg",
    description: "Classic rock band known for drama and harmony.",
    genre: "ROck", 
    profileLink: "artist-pages/fleetwood-mac.html"
  },
  {
    name: "Tame Impala",
    image: "assets/images/tame-impala.jpg",
    description: "Psychedelic pop project with dreamy production.",
    genre: "Electronic", 
    profileLink: "artist-pages/tame-impala.html"
  },
  {
    name: "David Bowie",
    image: "assets/images/david-bowie.jpg",
    description: "Ever-changing icon blending glam, rock, and theater.",
    genre: "Rock", 
    profileLink: "artist-pages/david-bowie.html"
  },
  {
    name: "girl in red",
    image: "assets/images/girl-in-red.jpg",
    description: "Queer indie pop star with emotional honesty.",
    genre: "Indie",  
    profileLink: "artist-pages/girl-in-red.html"
  },
  {
    name: "AC/DC",
    image: "assets/images/acdc.jpg",
    description: "High-voltage rock legends with timeless riffs.",
    genre: "Rock",  
    profileLink: "artist-pages/acdc.html"
  },
  {
    name: "My Chemical Romance",
    image: "assets/images/my-chemical-romance.jpg",
    description: "Emo band defining 2000s alt-rock angst.",
    genre: "Rock",  
    profileLink: "artist-pages/my-chemical-romance.html"
  },
  {
    name: "Bring Me The Horizon",
    image: "assets/images/bring-me-the-horizon.jpg",
    description: "Heavy rock band evolving from metalcore to alt-pop.",
    genre: "Metal",  
    profileLink: "artist-pages/bring-me-the-horizon.html"
  },
  {
    name: "Slipknot",
    image: "assets/images/slipknot.jpg",
    description: "Masked metal band known for intense live shows.",
    genre: "Metal", 
    profileLink: "artist-pages/slipknot.html"
  },
  {
    name: "System of a Down",
    image: "assets/images/system-of-a-down.jpg",
    description: "Armenian-American band mixing metal and activism.",
    genre: "Metal",  
    profileLink: "artist-pages/system-of-a-down.html"
  },
  {
    name: "Evanescence",
    image: "assets/images/evanescence.jpg",
    description: "Gothic rock band blending piano and metal.",
    genre: "Metal", 
    profileLink: "artist-pages/evanescence.html"
  },
  {
    name: "The Strokes",
    image: "assets/images/the-strokes.jpg",
    description: "Revivalist rock band with NYC cool.",
    genre: "Rock",  
    profileLink: "artist-pages/the-strokes.html"
  },
  {
    name: "The 1975",
    image: "assets/images/the-1975.jpg",
    description: "Alt-pop band mixing 80s synth with millennial angst.",
    genre: "Pop", 
    profileLink: "artist-pages/the-1975.html"
  },
  {
    name: "Muse",
    image: "assets/images/muse.jpg",
    description: "Epic arena rock with sci-fi themes.",
    genre: "Rock", 
    profileLink: "artist-pages/muse.html"
  },
  {
    name: "Cigarettes After Sex",
    image: "assets/images/cigarettes-after-sex.jpg",
    description: "Dream pop group with slow, cinematic sounds.",
    genre: "Chill", 
    profileLink: "artist-pages/cigarettes-after-sex.html"
  },
  {
    name: "The Neighbourhood",
    image: "assets/images/the-neighbourhood.jpg",
    description: "Alt-rock band behind the moody hit 'Sweater Weather'.",
    genre: "Pop",  
    profileLink: "artist-pages/the-neighbourhood.html"
  },
  {
    name: "Brent Faiyaz",
    image: "assets/images/brent-faiyaz.jpg",
    description: "R&B singer known for his toxic introspection.",
    genre: "R&B", 
    profileLink: "artist-pages/brent-faiyaz.html"
  },
  {
    name: "Lana Del Rey",
    image: "assets/images/lana-del-rey.jpg",
    description: "Melancholic pop icon with cinematic flair.",
    genre: "Chill",  
    profileLink: "artist-pages/lana-del-rey.html"
  },
  {
    name: "Joji",
    image: "assets/images/joji.jpg",
    description: "Lo-fi pop and soul artist rising from YouTube fame.",
    genre: "Electronic",  
    profileLink: "artist-pages/joji.html"
  },
  {
    name: "Frank Ocean",
    image: "assets/images/frank-ocean.jpg",
    description: "Critically acclaimed artist redefining R&B.",
    genre: "R&B",  
    profileLink: "artist-pages/frank-ocean.html"
  },
  {
    name: "Steve Lacy",
    image: "assets/images/steve-lacy.jpg",
    description: "Funk-influenced singer-guitarist with smooth vibes.",
    genre: "R&B", 
    profileLink: "artist-pages/steve-lacy.html"
  },
  {
    name: "TV Girl",
    image: "assets/images/tv-girl.jpg",
    description: "Nostalgic indie pop duo with vintage charm.",
    genre: "Lo-Fi", 
    profileLink: "artist-pages/tv-girl.html"
  },
  {
    name: "Beabadoobee",
    image: "assets/images/beabadoobee.jpg",
    description: "Grunge-inspired Gen Z indie rock artist.",
    genre: "Indie",  
    profileLink: "artist-pages/beabadoobee.html"
  },
  {
    name: "Clairo",
    image: "assets/images/clairo.jpg",
    description: "Bedroom pop pioneer with gentle vocals.",
    genre: "Pop",  
    profileLink: "artist-pages/clairo.html"
  },
  {
    name: "Beach House",
    image: "assets/images/beach-house.jpg",
    description: "Dream pop duo known for atmospheric soundscapes.",
    genre: "Indie",  
    profileLink: "artist-pages/beach-house.html"
  },
  {
    name: "Hozier",
    image: "assets/images/hozier.jpg",
    description: "Irish soul singer-songwriter behind 'Take Me to Church'.",
    genre: "Chill",  
    profileLink: "artist-pages/hozier.html"
  },
  {
    name: "Mazzy Star",
    image: "assets/images/mazzy-star.jpg",
    description: "90s dream folk band with soft, slow tunes.",
    genre: "Chill",  
    profileLink: "artist-pages/mazzy-star.html"
  },
  {
    name: "Jeff Buckley",
    image: "assets/images/jeff-buckley.jpg",
    description: "Legendary voice known for his cover of 'Hallelujah'.",
    genre: "Rock", 
    profileLink: "artist-pages/jeff-buckley.html"
  },
  {
    name: "Fiona Apple",
    image: "assets/images/fiona-apple.jpg",
    description: "Genius songwriter blending piano and confessional lyrics.",
    genre: "Pop", 
    profileLink: "artist-pages/fiona-apple.html"
  },
  {
    name: "Etta James",
    image: "assets/images/etta-james.jpg",
    description: "Soul icon behind the timeless hit 'At Last'.",
    genre: "Jazz", 
    profileLink: "artist-pages/etta-james.html"
  },
  {
    name: "Louis Armstrong",
    image: "assets/images/louis-armstrong.jpg",
    description: "Jazz pioneer with a gravelly voice and golden trumpet.",
    genre: "Jazz",  
    profileLink: "artist-pages/louis-armstrong.html"
  },
  {
    name: "Nina Simone",
    image: "assets/images/nina-simone.jpg",
    description: "Singer-activist blending jazz, blues, and civil rights.",
    genre: "Jazz",  
    profileLink: "artist-pages/nina-simone.html"
  },
  {
    name: "Miles Davis",
    image: "assets/images/miles-davis.jpg",
    description: "Revolutionary jazz trumpeter with decades of influence.",
    genre: "Jazz",  
    profileLink: "artist-pages/miles-davis.html"
  },
  {
    name: "Ella Fitzgerald",
    image: "assets/images/ella-fitzgerald.jpg",
    description: "Queen of jazz vocals with flawless phrasing.",
    genre: "Jazz",  
    profileLink: "artist-pages/ella-fitzgerald.html"
  },
  {
    name: "Ray Charles",
    image: "assets/images/ray-charles.jpg",
    description: "Pioneer of soul blending gospel, jazz, and blues.",
    genre: "Jazz", 
    profileLink: "artist-pages/ray-charles.html"
  },
  {
    name: "Billie Holiday",
    image: "assets/images/billie-holiday.jpg",
    description: "Jazz legend with a deep emotional voice.",
    genre: "Jazz", 
    profileLink: "artist-pages/billie-holiday.html"
  },
  {
    name: "Frank Sinatra",
    image: "assets/images/frank-sinatra.jpg",
    description: "Classic crooner with timeless swing and charm.",
    genre: "Jazz",  
    profileLink: "artist-pages/frank-sinatra.html"
  },
  {
    name: "Amr Diab",
    image: "assets/images/amr-diab.jpg",
    description: "Arabic pop legend blending modern and traditional sounds.",
    genre: "Pop", 
    profileLink: "artist-pages/amr-diab.html"
  },
];

// 3. Variables to access elements
const artistGrid = document.querySelector(".artist-grid");
const searchInput = document.getElementById("searchInput");
const genreButtons = document.querySelectorAll(".genre-btn");
const loadMoreBtn = document.getElementById("loadMoreBtn");
let visibleCount = 12;
let currentGenre = "All";

function renderArtists(list) {
  artistGrid.innerHTML = "";

  const toShow = list.slice(0, visibleCount);
  toShow.forEach((artist) => {
    const card = document.createElement("div");
    card.classList.add("artist-card");
    card.innerHTML = `
      <a href="${artist.profileLink}" class="artist-link">
        <h2>${artist.name}</h2>
        <p>${artist.description}</p>
      </a>
    `;
    artistGrid.appendChild(card);
  });

  // Show or hide Load More button
  if (list.length > visibleCount) {
    loadMoreBtn.style.display = "block";
  } else {
    loadMoreBtn.style.display = "none";
  }
}


// 5. Filter by search
searchInput?.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();
  const filtered = artists.filter((artist) =>
    artist.name.toLowerCase().includes(query) &&
    (currentGenre === "All" ? true : artist.genre === currentGenre)
  );
  renderArtists(filtered);
});

// 6. Filter by genre buttons
genreButtons?.forEach((btn) => {
  btn.addEventListener("click", () => {
    genreButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentGenre = btn.getAttribute("data-genre");
    const query = searchInput.value.toLowerCase();
    const filtered = artists.filter((artist) =>
      artist.name.toLowerCase().includes(query) &&
      (currentGenre === "All" ? true : artist.genre === currentGenre)
    );
    renderArtists(filtered);
  });
});

// 7. Initial page load
if (artistGrid) {
  renderArtists(artists);
}
// 8. Load More Button
loadMoreBtn?.addEventListener("click", () => {
  visibleCount += 8;
  const query = searchInput.value.toLowerCase();
  const filtered = artists.filter((artist) =>
    artist.name.toLowerCase().includes(query) &&
    (currentGenre === "All" ? true : artist.genre === currentGenre)
  );
  renderArtists(filtered);
});
